# text analysis to drive sentimental opinion, sentiment scores, readability, passive words, personal pronouns 
